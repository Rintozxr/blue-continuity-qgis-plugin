# -*- coding: utf-8 -*-
from qgis.core import QgsVectorLayer

def compare_layers(layer_list, thresh=0.8):
    """
    占位函数：返回第一层原样
    """
    if not layer_list:
        raise ValueError("layer_list 为空")
    return layer_list[0]